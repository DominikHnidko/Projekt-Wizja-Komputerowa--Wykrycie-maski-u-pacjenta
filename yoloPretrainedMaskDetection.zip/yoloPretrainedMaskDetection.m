clc;
clear all;

%zZaładowany dataset
data = load("MASKIDATASET.mat");
peopleDataSet = data.T;
%bierzemy z data setu tylko 370 pozycji
peopleDataSet = peopleDataSet(1:370,:)
T=data.T;


%%%%%%%%%%%%%%%%%%%%%%%%%
% Przyklad: T.col1 to kolumna z pustymi []
% col1 = data.T.filename(~cellfun(@isempty, T.filename));
% col2 = data.T.withMask(~cellfun(@isempty, T.withMask));
% col3 = data.T.withoutMask(~cellfun(@isempty, T.withoutMask));
% col4 = data.T.incorrectMask(~cellfun(@isempty, T.incorrectMask));
% 
% mask = ~cellfun(@isempty, T.incorrectMask);   % które wiersze są niepuste w col4
% 
% col4 = T.incorrectMask(mask);                 % oczyszczona col4
% col1 = T.filename(mask);                 % odpowiadające elementy z col1
%%%%%%%%%%%%%%%%%%%%%%%%%





%Ustawiamy poprawną ścieżke do naszych obrazów
peopleDataSet.filename = fullfile('Z:\POBRANE_Y\face-mask-detection-DatasetNinja\ds\img',peopleDataSet.filename);


%Split the dataset into training, validation, and test sets...
rng("default")
peopleDataSetLength=length(peopleDataSet.filename);
randNum = randperm(length(peopleDataSet.filename));
randNum = randNum.';

idx = floor(0.8 *peopleDataSetLength);

trainingIdx=1:idx;
%bierzemy tyle elementow co w trainingIdx z randNum
trainingDataTbl  = peopleDataSet(randNum(trainingIdx),:)

validationIdx = idx+1 : idx + 1 + floor(0.1 * length(randNum) );
validationDataTbl = peopleDataSet(randNum(validationIdx),:);

testIdx = validationIdx(end)+1 : length(randNum);
testDataTbl = peopleDataSet(randNum(testIdx),:);

%Tworzymy DataStore'y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 imdsTrain = imageDatastore(trainingDataTbl{:,"filename"});
 bldsTrain = boxLabelDatastore(trainingDataTbl(:,2:end));

 imdsValidation = imageDatastore(validationDataTbl{:,"filename"});
bldsValidation = boxLabelDatastore(validationDataTbl(:,2:end));

imdsTest = imageDatastore(testDataTbl{:,"filename"});
bldsTest = boxLabelDatastore(testDataTbl(:,2:end));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Combine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
trainingData = combine(imdsTrain,bldsTrain);
validationData = combine(imdsValidation,bldsValidation);
testData = combine(imdsTest,bldsTest);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%  The func validates the input images, bounding boxes and labels and displays the 
% paths of invalid samples. 
validateInputData(trainingData);
validateInputData(validationData);
validateInputData(testData);

%okreslamy input size zgodnie z wymaganiami yolo
inputSize = [416 416 3];


%pkreślamy występujące klasy 
className = ["withMask","withoutMask", "incorrectMask"];


%estymujemy anchor boxy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rng("default")
trainingDataForEstimation = transform(trainingData,@(data)preprocessData(data,inputSize));
numAnchors = 6;
[anchors,meanIoU] = estimateAnchorBoxes(trainingDataForEstimation,numAnchors);



area = anchors(:, 1).*anchors(:,2);
[~,idx] = sort(area,"descend");

anchors = anchors(idx,:);
anchorBoxes = {anchors(1:3,:)
    anchors(4:6,:)};%???????????
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


detector = yolov4ObjectDetector("tiny-yolov4-coco",className,anchorBoxes,InputSize=inputSize);


%augumentacja danych
augmentedTrainingData = transform(trainingData,@augmentData);
augmentedData = cell(4,1);
for k = 1:4
    data = read(augmentedTrainingData);
    augmentedData{k} = insertShape(data{1},"rectangle",data{2});
    reset(augmentedTrainingData);
end
figure
montage(augmentedData,BorderSize=10)

%ustawienia trenowania
options = trainingOptions("adam", ...
    GradientDecayFactor=0.9, ...
    SquaredGradientDecayFactor=0.999, ...
    InitialLearnRate=0.001, ...
    LearnRateSchedule="none", ...
    MiniBatchSize=4, ...
    L2Regularization=0.0005, ...
    MaxEpochs=80, ...
    DispatchInBackground=true, ...
    ResetInputNormalization=true, ...
    Shuffle="every-epoch", ...
    VerboseFrequency=20, ...
    ValidationFrequency=1000, ...
    CheckpointPath=tempdir, ...
    ValidationData=validationData, ...
    OutputNetwork="best-validation-loss");

     
    % Train the YOLO v4 detector. 
    % [detector_1,info_1] = trainYOLOv4ObjectDetector(augmentedTrainingData,detector,options);

%%correct 

% 
% % url = 'http://10.98.221.244/capture';
% % data = webread(url);
% % size(data)
% 
% load detector
% figure;
% 
%   % data = webread(url);
%   % data = imresize(data,[416 416]);
%  % imshow(data)
%  data=snapshot(cam);
% 
% [bboxes, scores, labels] = detect(detector, img, ...
%     'Threshold', 0.9);
% data = insertObjectAnnotation(data,"rectangle",bboxes,scores);
%  imshow(data)
% 
